
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/evaluate.mjs
var MAX_SILENT_HOURS = 36;
var HOUR = 3600 * 1e3;
var DAY = 24 * HOUR;
function weekdayMs(fromMs, toMs) {
  if (toMs <= fromMs) return 0;
  let total = 0;
  let cursor = fromMs;
  while (cursor < toMs) {
    const dayStart = cursor - cursor % DAY;
    const dayEnd = Math.min(dayStart + DAY, toMs);
    const weekday = new Date(dayStart).getUTCDay();
    if (weekday !== 0 && weekday !== 6) total += dayEnd - cursor;
    cursor = dayEnd;
  }
  return total;
}
function evaluate(status, nowMs, maxSilentHours = MAX_SILENT_HOURS) {
  if (!status || typeof status !== "object") return { code: 503, body: { state: "unknown", why: "no status file" } };
  const last = Date.parse(status.last_event_at ?? "");
  const made = Date.parse(status.generated_at ?? "");
  if (Number.isNaN(last) || Number.isNaN(made)) return { code: 503, body: { state: "unknown", why: "no time in the status file" } };
  if (last > nowMs + 5 * 60 * 1e3 || made > nowMs + 5 * 60 * 1e3) return { code: 503, body: { state: "invalid", why: "a time in the future" } };
  const silentLast = weekdayMs(last, nowMs) / HOUR;
  const silentMade = weekdayMs(made, nowMs) / HOUR;
  const body = {
    last_routine: String(status.last_routine ?? ""),
    last_event_at: status.last_event_at,
    silent_weekday_hours: Math.round(silentLast * 10) / 10,
    kill_engaged: status.kill_engaged === true,
    mode: String(status.mode ?? "")
  };
  if (silentMade > maxSilentHours) return { code: 503, body: { ...body, state: "stale", why: "the status file was not refreshed" } };
  if (silentLast > maxSilentHours) return { code: 503, body: { ...body, state: "stale", why: "no routine has run" } };
  return { code: 200, body: { ...body, state: body.kill_engaged ? "killed" : "ok" } };
}

// netlify/functions/status.mjs
var config = { path: "/status" };
var status_default = async (req) => {
  let status = null;
  try {
    const res = await fetch(new URL("/status.json", req.url), { headers: { "cache-control": "no-cache" } });
    if (res.ok) status = await res.json();
  } catch {
    status = null;
  }
  const { code, body } = evaluate(status, Date.now());
  return new Response(JSON.stringify(body), {
    status: code,
    headers: { "content-type": "application/json", "cache-control": "no-store" }
  });
};
export {
  config,
  status_default as default
};
